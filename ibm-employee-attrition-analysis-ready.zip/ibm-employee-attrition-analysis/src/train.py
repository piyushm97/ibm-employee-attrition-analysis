
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from joblib import dump
import argparse

from src.preprocess import TARGET_COL, CATEGORICAL, NUMERIC

def load_data(path: str):
    df = pd.read_csv(path)
    return df

def build_pipeline(model_name: str):
    ohe = OneHotEncoder(handle_unknown="ignore", drop="first")
    pre = ColumnTransformer(
        transformers=[("cat", ohe, CATEGORICAL), ("num", "passthrough", NUMERIC)]
    )
    if model_name == "rf":
        model = RandomForestClassifier(n_estimators=300, random_state=42, class_weight="balanced")
    else:
        model = LogisticRegression(max_iter=2000, class_weight="balanced")
    pipe = Pipeline([("pre", pre), ("clf", model)])
    return pipe

def main(args):
    df = load_data(args.data)
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL].map({"Yes":1,"No":0}).astype(int)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    pipe = build_pipeline(args.model)
    pipe.fit(X_train, y_train)

    y_pred = pipe.predict(X_test)
    y_prob = pipe.predict_proba(X_test)[:,1] if hasattr(pipe, "predict_proba") else None

    print("== Classification Report ==")
    print(classification_report(y_test, y_pred, digits=4))
    if y_prob is not None:
        try:
            print("ROC AUC:", roc_auc_score(y_test, y_prob))
        except Exception:
            pass

    dump(pipe, args.output)
    print(f"Model saved to {args.output}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/sample_ibm_attrition.csv", help="Path to CSV with Attrition column Yes/No")
    parser.add_argument("--model", choices=["logreg","rf"], default="rf")
    parser.add_argument("--output", default="models/attrition_model.joblib")
    main(parser.parse_args())
