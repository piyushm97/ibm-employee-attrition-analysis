
import pandas as pd

TARGET_COL = "Attrition"  # Yes/No

CATEGORICAL = [
    "Department","EducationField","EnvironmentSatisfaction","Gender","JobRole",
    "JobSatisfaction","MaritalStatus","OverTime","PerformanceRating","RelationshipSatisfaction",
    "StockOptionLevel","WorkLifeBalance"
]

NUMERIC = [
    "Age","DistanceFromHome","Education","MonthlyIncome","NumCompaniesWorked",
    "PercentSalaryHike","TotalWorkingYears","TrainingTimesLastYear",
    "YearsAtCompany","YearsInCurrentRole","YearsSinceLastPromotion","YearsWithCurrManager"
]

def split_X_y(df: pd.DataFrame):
    df = df.copy()
    y = df[TARGET_COL].map({"Yes":1,"No":0}).astype(int)
    X = df.drop(columns=[TARGET_COL])
    return X, y

def prepare_features(df: pd.DataFrame):
    # ensure columns exist even if missing in uploaded data
    for c in CATEGORICAL + NUMERIC:
        if c not in df.columns:
            df[c] = 0 if c in NUMERIC else "Unknown"
    # restrict to known columns
    df = df[CATEGORICAL + NUMERIC]
    # one-hot encode categoricals; keep numeric as-is
    X = pd.get_dummies(df, columns=CATEGORICAL, drop_first=True)
    return X
